"""PC2 코스 계획 및 반원 지오메트리: ROS 없이 단독 테스트 가능.

User's final diagram: robot position (not visitor) determines half-disc membership.
No fabricated positions: YAML must contain real surveyed map-frame coordinates.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Optional
import json
import math
import uuid
import yaml


def number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError(f"{name}: 숫자 좌표가 필요합니다: {value!r}")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name}: NaN/Inf는 사용할 수 없습니다")
    return result


@dataclass(frozen=True)
class Pose2D:
    x: float
    y: float
    yaw: float = 0.0  # radian, map frame

    @classmethod
    def parse(cls, data: Any) -> 'Pose2D':
        if not isinstance(data, dict):
            raise ValueError('goal_pose: {x, y, yaw} 딕셔너리가 필요합니다')
        return cls(number(data.get('x'), 'goal_pose.x'),
                   number(data.get('y'), 'goal_pose.y'),
                   number(data.get('yaw', 0), 'goal_pose.yaw'))


@dataclass(frozen=True)
class Semicircle:
    cx: float
    cy: float
    radius: float
    direction: float  # 정면을 가리키는 각도(rad). cos/sin 방향 반평면만 허용.

    @classmethod
    def parse(cls, data: Any) -> 'Semicircle':
        if not isinstance(data, dict):
            raise ValueError('zone: {cx, cy, radius, direction} 딕셔너리가 필요합니다')
        obj = cls(number(data.get('cx'), 'zone.cx'),
                  number(data.get('cy'), 'zone.cy'),
                  number(data.get('radius'), 'zone.radius'),
                  number(data.get('direction'), 'zone.direction'))
        if obj.radius <= 0:
            raise ValueError('반원의 반지름은 양수여야 합니다')
        return obj

    def contains(self, location: Pose2D | tuple[float, float], epsilon: float = 1e-7) -> bool:
        if isinstance(location, Pose2D):
            x, y = location.x, location.y
        else:
            x, y = location
        dx, dy = x - self.cx, y - self.cy
        return (dx * dx + dy * dy <= (self.radius + epsilon) ** 2
                and dx * math.cos(self.direction) + dy * math.sin(self.direction) >= -epsilon)


@dataclass(frozen=True)
class Artwork:
    artwork_id: str
    goal: Pose2D
    zone: Semicircle
    explanation_id: str


@dataclass(frozen=True)
class CoursePlan:
    kiosk_goal: Pose2D
    kiosk_zone: Semicircle
    artworks: tuple[Artwork, ...]
    # REAL ROBOT additions: exit stop (no semicircle) and fixed dock approach.
    exit_goal: Optional[Pose2D] = None
    farewell_text: str = '안녕히가세요'
    dock_station: Optional[Pose2D] = None
    dock_approach: Optional[Pose2D] = None

    def selected(self, ids: Optional[tuple[str, ...]]) -> 'CoursePlan':
        if ids is None:
            return self
        if not ids:
            raise ValueError('선택 작품 목록이 비었습니다')
        by_id = {art.artwork_id: art for art in self.artworks}
        if len(set(ids)) != len(ids):
            raise ValueError('선택 작품 목록에 중복된 ID가 있습니다')
        missing = [a for a in ids if a not in by_id]
        if missing:
            raise ValueError(f'등록되지 않은 작품 ID: {missing}')
        return replace(self, artworks=tuple(by_id[id_] for id_ in ids))


@dataclass(frozen=True)
class CourseRequest:
    request_id: str
    all_artworks: bool
    artwork_ids: Optional[tuple[str, ...]]


def parse_course_request(raw: str) -> CourseRequest:
    """PC3 문자열 A, B:1,3 또는 JSON 계약 모두 허용."""
    raw = raw.strip()
    if not raw:
        raise ValueError('코스 요청이 비었습니다')
    if raw.upper() in {'A', 'ALL'}:
        return CourseRequest(str(uuid.uuid4()), True, None)
    if raw.upper().startswith('B:'):
        ids = tuple(part.strip() for part in raw[2:].split(','))
        if not ids or any(not t for t in ids):
            raise ValueError('B:1,3 형식으로 선택 작품을 입력하세요')
        return CourseRequest(str(uuid.uuid4()), False, ids)
    try:
        data = json.loads(raw)
    except (ValueError, TypeError) as error:
        raise ValueError('요청은 A, B:1,3 또는 JSON이어야 합니다') from error
    if not isinstance(data, dict):
        raise ValueError('JSON 요청은 객체여야 합니다')
    if data.get('mode') != 'COURSE':
        raise ValueError('PC2는 mode=COURSE만 처리합니다')
    rid = data.get('request_id')
    if not isinstance(rid, str) or not rid.strip() or len(rid) > 128:
        raise ValueError('request_id는 1~128자 문자열이어야 합니다')
    all_ = data.get('all_artworks')
    if not isinstance(all_, bool):
        raise ValueError('all_artworks는 true/false이어야 합니다')
    ids = data.get('artwork_ids', [])
    if not isinstance(ids, list):
        raise ValueError('artwork_ids는 배열이어야 합니다')
    if any(not isinstance(x, (str, int)) or isinstance(x, bool) for x in ids):
        raise ValueError('artwork_ids에는 문자열 또는 정수만 허용합니다')
    normalized = tuple(str(x).strip() for x in ids)
    if not all_ and (not normalized or any(not x for x in normalized)):
        raise ValueError('선택 코스는 1개 이상의 작품 ID를 포함해야 합니다')
    if all_ and normalized:
        raise ValueError('전체 관람은 artwork_ids를 비워야 합니다')
    return CourseRequest(rid, all_, None if all_ else normalized)


def load_course_config(path: str | Path) -> CoursePlan:
    """누락된 좌표는 즉시 실패시켜 로봇의 잘못된 이동을 방지."""
    data = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('YAML 최상위 값은 객체여야 합니다')
    kiosk = data.get('kiosk')
    if not isinstance(kiosk, dict):
        raise ValueError('kiosk 설정이 없습니다')
    kiosk_goal = Pose2D.parse(kiosk.get('goal_pose'))
    kiosk_zone = Semicircle.parse(kiosk.get('zone'))
    if not kiosk_zone.contains(kiosk_goal):
        raise ValueError('키오스크 goal_pose가 키오스크 반원 바깥입니다')
    items = data.get('artworks')
    if not isinstance(items, list) or not items:
        raise ValueError('artworks는 하나 이상의 작품 목록이어야 합니다')
    works = []
    for item in items:
        if not isinstance(item, dict) or not str(item.get('artwork_id', '')).strip():
            raise ValueError('각 작품의 artwork_id가 필요합니다')
        art_id = str(item['artwork_id'])
        goal = Pose2D.parse(item.get('goal_pose'))
        zone = Semicircle.parse(item.get('zone'))
        if not zone.contains(goal):
            raise ValueError(f'{art_id}: goal_pose가 해당 작품의 반원 바깥입니다')
        works.append(Artwork(art_id, goal, zone,
                             str(item.get('explanation_id', art_id))))
    if len({a.artwork_id for a in works}) != len(works):
        raise ValueError('artwork_id가 중복되었습니다')
    exit_goal = None
    farewell = '안녕히가세요'
    exit_cfg = data.get('exit')
    if exit_cfg is not None:
        if not isinstance(exit_cfg, dict):
            raise ValueError('exit 설정은 객체여야 합니다')
        exit_goal = Pose2D.parse(exit_cfg.get('goal_pose'))
        farewell = str(exit_cfg.get('farewell', farewell))
    station = approach = None
    dock_cfg = data.get('dock')
    if dock_cfg is not None:
        if not isinstance(dock_cfg, dict):
            raise ValueError('dock 설정은 객체여야 합니다')
        station = Pose2D.parse(dock_cfg.get('station'))
        approach = Pose2D.parse(dock_cfg.get('approach_pose'))
    return CoursePlan(kiosk_goal, kiosk_zone, tuple(works),
                      exit_goal, farewell, station, approach)


def resolve_selection(base: CoursePlan, request: CourseRequest) -> CoursePlan:
    return base.selected(request.artwork_ids)
