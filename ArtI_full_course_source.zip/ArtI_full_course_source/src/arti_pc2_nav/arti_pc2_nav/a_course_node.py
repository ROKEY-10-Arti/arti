"""ArtI PC2: ROS2 Jazzy/Nav2 course orchestration. No object perception enabled.

Map-frame goal coordinates are always loaded from surveyed configuration, never
fabricated. Never publish cmd_vel: Nav2's controller exclusively owns motion.
"""
from __future__ import annotations
import json
import math
import time
from typing import Optional

import rclpy
from rclpy.time import Time
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Odometry
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data, QoSProfile, DurabilityPolicy, ReliabilityPolicy
from tf2_ros import Buffer, TransformListener
from sensor_msgs.msg import BatteryState, LaserScan
from std_msgs.msg import String

from .course_engine import TourMachine, Event
from .guided_tour_plan import Pose2D, parse_course_request, load_course_config

try:
    from arti_interfaces.action import ExplainArtwork
except ImportError:
    ExplainArtwork = None

try:
    from irobot_create_msgs.action import Undock, Dock
    from irobot_create_msgs.msg import DockStatus
except ImportError:
    Undock = None
    Dock = None
    DockStatus = None


class ACourseNode(Node):
    def __init__(self):
        super().__init__('a_course_node')
        self.declare_parameter('config_file', '')
        self.declare_parameter('enable_motion', False)
        self.declare_parameter('simulation_mode', False)
        self.declare_parameter('skip_undock', False)
        self.declare_parameter('simulation_battery_percent', -1.0)
        self.declare_parameter('minimum_battery_percent', 30.0)
        self.declare_parameter('map_frame', 'map')
        self.declare_parameter('initial_pose_timeout', 3.0)
        self.declare_parameter('undock_timeout', 25.0)
        self.declare_parameter('dock_timeout', 90.0)
        self.declare_parameter('require_dock_status', True)
        # Explicit mock only; never labels a physical-docking success as COMPLETED.
        self.declare_parameter('simulate_docking', False)
        self.declare_parameter('require_tf', True)
        # 'action' = arti_interfaces/ExplainArtwork, 'topic' = hardcoded_tts_node
        # (arti/explanation_request -> arti/explanation_result, JSON String).
        self.declare_parameter('explanation_transport', 'action')
        # REAL ROBOT: TurtleBot4 power_saver stops the LiDAR while docked, so
        # scan/AMCL/TF are stale until undock. Wait for them after undocking.
        self.declare_parameter('post_undock_sensor_timeout', 30.0)
        self._await_sensors_since = None
        self._sensors_ok_since = None
        # Nav2 needs a few seconds after LiDAR restarts before it can use the
        # new map->odom TF; dispatching earlier is aborted ('Initial robot pose').
        self.declare_parameter('post_undock_settle_time', 3.0)
        from lifecycle_msgs.srv import GetState
        self._lifecycle_type = GetState
        self._lifecycle_sent = {}
        self._lifecycle = {name: [self.create_client(GetState, name+'/get_state'), None, False]
                           for name in ('amcl','map_server','bt_navigator','controller_server','planner_server')}

        self._pose: Optional[Pose2D] = None
        self._pose_stamp = 0.0
        self._scan_stamp = 0.0
        self._odom_stamp = 0.0
        self._speed = None
        self._battery = None
        self._battery_stamp = 0.0
        self._pending_cancel = False
        self._goal_handle = None
        self._undocking = False
        self._undock_started = 0.0
        self._undock_goal = None
        self._undock_failed_latched = False
        self._docking_inflight = False
        self._dock_goal = None
        self._dock_status_stamp = 0.0
        self._is_docked = None
        self._pending_nav = None
        self._nav_inflight = False
        self._cancel_inflight = False
        self._tf_at = 0.0
        self._tf_buffer = Buffer()
        self._tf_listener = TransformListener(self._tf_buffer, self)
        self._session = 0
        self._nav_generation = 0
        self._machine = None
        self._config_error = None
        try:
            filename = self.get_parameter('config_file').value
            if not filename:
                raise ValueError('config_file 미지정')
            self._machine = TourMachine(
                load_course_config(filename),
                simulate_explanation=bool(self.get_parameter('simulation_mode').value),
                dock_timeout=float(self.get_parameter('dock_timeout').value))
        except Exception as exc:
            self._config_error = str(exc)
            self.get_logger().error(f'좌표 설정 오류. 이동 차단: {self._config_error}')

        self._nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self._undock_client = ActionClient(self, Undock, 'undock') if Undock else None
        self._dock_client = ActionClient(self, Dock, 'dock') if Dock else None
        self._explain_client = ActionClient(self, ExplainArtwork, 'explain_artwork') if ExplainArtwork else None
        self._explain_goal = None
        self._status_pub = self.create_publisher(String, '/arti/course_status', 10)
        self._guide_pub = self.create_publisher(String, 'guide_message', 10)
        self._explanation_pub = self.create_publisher(String, 'arti/explanation_request', 10)
        self.create_subscription(String, '/arti/course_request', self._on_request, 10)
        self.create_subscription(String, 'arti/tour/select', self._on_request, 10)
        amcl_qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                              reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(PoseWithCovarianceStamped, 'amcl_pose', self._on_pose, amcl_qos)
        self.create_subscription(Odometry, 'odom', self._on_odom, qos_profile_sensor_data)
        self.create_subscription(LaserScan, 'scan', self._on_scan, qos_profile_sensor_data)
        self.create_subscription(BatteryState, 'battery_state', self._on_battery, qos_profile_sensor_data)
        if DockStatus is not None:
            self.create_subscription(DockStatus, 'dock_status', self._on_dock_status,
                                     qos_profile_sensor_data)
        # TODO(OBJECT DETECTION TEAM): Connect registered-visitor ID and
        # timestamped, map-frame target detections here after agreeing ROS API.
        # self.create_subscription(RegisteredVisitor, 'visitor/registered', self._on_registered, ...)
        # self.create_subscription(TrackedVisitor, 'visitor/tracking', self._on_tracking, ...)
        # In this PC2-only test, KIOSK_STOPPED proceeds without visitor recognition.
        # TODO(AUDIO TEAM): replace simulation's 2-second narration with
        # ExplainArtwork action/service and feed its result to explanation_result().
        # Optional JSON adapter for non-simulation integration if arti_interfaces is unavailable.
        self.create_subscription(String, 'arti/explanation_result', self._on_explanation_result, 10)
        self.create_subscription(String, '/arti/course_recovery', self._on_recovery, 10)
        # TODO(PC3 TEAM): /arti/get_course service and /arti/course_status response
        # should use their agreed interface; String/JSON is a temporary adapter.
        self.create_timer(.1, self._tick)
        self.get_logger().info('PC2 node initialized; enable_motion must be true to accept requests')

    def _now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _on_pose(self, msg):
        # AMCL / map frame is mandatory; odom frame must not be used as map.
        if msg.header.frame_id and msg.header.frame_id.lstrip('/') != self.get_parameter('map_frame').value.lstrip('/'):
            return
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        yaw = math.atan2(2*(q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z))
        self._pose = Pose2D(p.x, p.y, yaw)
        self._pose_stamp = self._now()

    def _on_odom(self, msg):
        vel = msg.twist.twist
        self._speed = max(math.hypot(vel.linear.x, vel.linear.y), abs(vel.angular.z))
        self._odom_stamp = self._now()

    def _on_scan(self, _msg):
        self._scan_stamp = self._now()

    def _on_battery(self, msg):
        if math.isfinite(msg.percentage) and msg.percentage >= 0:
            self._battery = 100.0*msg.percentage if msg.percentage <= 1.0 else msg.percentage
            self._battery_stamp = self._now()

    def _on_dock_status(self, msg):
        self._is_docked = bool(msg.is_docked)
        self._dock_status_stamp = self._now()

    def _emit(self, payload):
        obj = dict(payload)
        obj['simulation'] = bool(self.get_parameter('simulation_mode').value)
        data = json.dumps(obj, ensure_ascii=False)
        self._status_pub.publish(String(data=data))
        self.get_logger().info(data)

    def _reject(self, text):
        self._emit({'request_id': '', 'state': 'REJECTED', 'detail': text, 'completed': []})

    def _check_ready(self):
        now = self._now()
        if self._machine is None:
            return self._config_error or '코스 설정 오류'
        if not self.get_parameter('enable_motion').value:
            return 'enable_motion=false (안전 잠금)'
        docked = (self._is_docked is True and now - self._dock_status_stamp < 3.0)
        if self._pose is None:
            return 'AMCL map 위치 정보 없음 (RViz 2D Pose Estimate 필요)'
        if now - self._odom_stamp > 3.0:
            return 'Odometry 신호가 없음'
        # Docked: LiDAR is off (power_saver); these are re-checked after undock.
        if not docked:
            if now - self._pose_stamp > 3.0:
                return 'AMCL map 위치 정보가 신선하지 않음'
            if now - self._scan_stamp > 3.0:
                return 'LiDAR scan 신호가 없음'
            if self.get_parameter('require_tf').value and now - self._tf_at > 3.0:
                return 'map -> base_link TF 변환 미수신 또는 만료'
        if not self._nav_client.server_is_ready():
            return 'Nav2 navigate_to_pose 액션 미준비'
        if not all(v[2] for v in self._lifecycle.values()):
            return 'AMCL/map_server/Nav2 lifecycle not active'
        if not self.get_parameter('simulation_mode').value:
            if self.get_parameter('explanation_transport').value == 'topic':
                if self._explanation_pub.get_subscription_count() == 0:
                    return 'TTS 노드 미실행 (arti/explanation_request 구독자 없음)'
            elif self._explain_client is None or not self._explain_client.server_is_ready():
                return '실물 ExplainArtwork 액션 미준비'
        # Fail before navigation rather than discovering absent dock only after art 4.
        mock_dock = (self.get_parameter('simulation_mode').value and
                     self.get_parameter('simulate_docking').value)
        if not mock_dock and (self._dock_client is None or not self._dock_client.server_is_ready()):
            return 'Dock 액션 서버 미준비 (simulation_mode에서 simulate_docking:=true는 모의 검증 전용)'
        battery = self._battery if (now - self._battery_stamp < 5.0) else None
        if battery is None and self.get_parameter('simulation_mode').value:
            fallback = float(self.get_parameter('simulation_battery_percent').value)
            battery = fallback if fallback >= 0 else None
        if battery is None:
            return '배터리 정보 없음 (시뮬레이션이면 시험값을 명시해야 함)'
        if battery < self.get_parameter('minimum_battery_percent').value:
            return f'배터리 부족: {battery:.1f}%'
        return None

    def _on_request(self, msg):
        if (self._undocking or self._await_sensors_since is not None or self._docking_inflight or self._dock_goal is not None
                or self._nav_inflight or self._goal_handle is not None
                or self._undock_failed_latched
                or (self._machine and self._machine.state not in ('IDLE','DONE','ERROR'))):
            self._reject('코스주행 중복 요청')
            return
        try:
            req = parse_course_request(msg.data)
        except ValueError as exc:
            self._reject(str(exc)); return
        reason = self._check_ready()
        if reason:
            self._reject(reason); return
        if not req.all_artworks:
            self._reject('이번 구현은 전체 코스 A 전용입니다'); return
        if self._is_docked is None or self._now()-self._dock_status_stamp > 3.0:
            self._reject('최신 dock_status 없음'); return
        self._session += 1
        self._pending_cancel = False
        self._goal_handle = None
        try:
            # Exact initial dock station pose is recorded BEFORE undocking.
            # Navigation return target is updated to a collision-safe pose AFTER undock.
            events = self._machine.start(req, self._now(), self._pose)
        except ValueError as exc:
            self._reject(str(exc)); return
        if self._is_docked is False:
            self._machine.set_post_undock_pose(self._pose)
            self._dispatch(events)
        elif self.get_parameter('skip_undock').value:
            if not self.get_parameter('simulation_mode').value:
                self._dispatch(self._machine.fail('실기에서는 도킹 해제를 임의로 건너뛸 수 없습니다'))
                return
            self._emit({'request_id': req.request_id, 'state': 'UNDOCK_SKIPPED',
                        'detail': '시뮬레이터 시작 시 이미 undocked라고 가정', 'completed': []})
            self._dispatch(events)
        else:
            if self._undock_client is None or not self._undock_client.server_is_ready():
                self._dispatch(self._machine.fail('Undock 액션 서버 미준비'))
                return
            self._undocking = True
            self._undock_started = self._now()
            self._pending_nav = events
            future = self._undock_client.send_goal_async(Undock.Goal())
            future.add_done_callback(self._undock_accepted)

    def _undock_accepted(self, future):
        try:
            gh = future.result()
            if not gh.accepted:
                raise RuntimeError('Undock goal rejected')
            self._undock_goal = gh
            if not self._undocking:
                self._undock_failed_latched = True
                gh.cancel_goal_async()
                return
            gh.get_result_async().add_done_callback(self._undock_finished)
        except Exception as exc:
            self._undocking = False
            self._undock_failed_latched = True
            self._dispatch(self._machine.fail(f'Undock 실패: {exc}'))

    def _undock_finished(self, future):
        if not self._undocking:
            return  # timed-out action callback; operator intervention required
        self._undocking = False
        self._undock_goal = None
        try:
            response = future.result()
            if response.status != GoalStatus.STATUS_SUCCEEDED:
                raise RuntimeError(f'Undock status {response.status}')
            # REAL ROBOT: LiDAR restarts after undock; _tick waits for fresh
            # scan + AMCL/TF before saving the home pose and starting Nav2.
            self._await_sensors_since = self._now()
            self._emit({'request_id': self._machine.request_id, 'state': 'UNDOCKED_WAITING_SENSORS',
                        'detail': 'LiDAR/AMCL/TF 재수신 대기', 'completed': []})
        except Exception as exc:
            self._undock_failed_latched = True
            self._pending_nav = None
            self._dispatch(self._machine.fail(f'Undock 실패: {exc}'))

    def _finish_post_undock(self, now):
        self._await_sensors_since = None
        events, self._pending_nav = self._pending_nav, None
        try:
            origin = self._machine.dock_origin
            home = Pose2D(self._pose.x, self._pose.y, math.atan2(origin.y-self._pose.y, origin.x-self._pose.x))
            self._machine.set_post_undock_pose(home)
            hg = self._machine.home_goal
            self._emit({'request_id': self._machine.request_id, 'state': 'UNDOCKED',
                        'detail': f'언도킹 위치 ({self._pose.x:.3f}, {self._pose.y:.3f}); 복귀 목표 ({hg.x:.3f}, {hg.y:.3f})',
                        'completed': []})
            self._dispatch(events)
        except Exception as exc:
            self._undock_failed_latched = True
            self._dispatch(self._machine.fail(f'Undock 후 처리 실패: {exc}'))

    def _dispatch(self, events: list[Event]):
        for event in events:
            if event.kind == 'status':
                self._emit(event.value)
            elif event.kind == 'navigate':
                name, pose = event.value
                self._send_nav(name, pose)
            elif event.kind == 'cancel':
                self._cancel_nav()
            elif event.kind == 'guide':
                self._guide_pub.publish(String(data=str(event.value)))
            elif event.kind == 'dock':
                self._start_docking()
            elif event.kind == 'explain':
                self._emit({'request_id': self._machine.request_id,
                            'state': 'EXPLANATION_REQUESTED',
                            'detail': str(event.value), 'completed': list(self._machine.completed)})
                if not self.get_parameter('simulation_mode').value:
                    self._start_explanation(str(event.value))

    def _send_nav(self, name, pose):
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = self.get_parameter('map_frame').value
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = pose.x
        goal.pose.pose.position.y = pose.y
        goal.pose.pose.orientation.z = math.sin(pose.yaw / 2)
        goal.pose.pose.orientation.w = math.cos(pose.yaw / 2)
        self._goal_handle = None
        self._nav_inflight = True
        self._cancel_inflight = False
        self._pending_cancel = False
        self._nav_generation += 1
        session = (self._session, self._nav_generation)
        self._emit({'request_id': self._machine.request_id, 'state': 'NAVIGATING',
                    'detail': str(name), 'completed': list(self._machine.completed)})
        future = self._nav_client.send_goal_async(goal)
        future.add_done_callback(lambda f: self._nav_accepted(f, session))

    def _nav_accepted(self, future, session):
        if session != (self._session, self._nav_generation):
            return
        try:
            gh = future.result()
            self._nav_inflight = False
            if not gh.accepted:
                self._dispatch(self._machine.nav_result('REJECTED', self._now()))
                return
            self._goal_handle = gh
            gh.get_result_async().add_done_callback(lambda f: self._nav_finished(f, session))
            if self._pending_cancel:
                self._cancel_nav()
        except Exception as exc:
            self._nav_inflight = False
            self._dispatch(self._machine.fail(f'Nav2 전송 실패: {exc}'))

    def _nav_finished(self, future, session):
        if session != (self._session, self._nav_generation):
            return
        self._goal_handle = None
        self._cancel_inflight = False
        try:
            status = future.result().status
            name = {GoalStatus.STATUS_SUCCEEDED:'SUCCEEDED',
                    GoalStatus.STATUS_CANCELED:'CANCELED',
                    GoalStatus.STATUS_ABORTED:'ABORTED'}.get(status, f'STATUS_{status}')
            self._dispatch(self._machine.nav_result(name, self._now()))
        except Exception as exc:
            self._dispatch(self._machine.fail(f'Nav2 결과 확인 실패: {exc}'))

    def _cancel_nav(self):
        if self._cancel_inflight:
            return
        if self._goal_handle is None:
            self._pending_cancel = True
            return
        self._pending_cancel = False
        self._cancel_inflight = True
        future = self._goal_handle.cancel_goal_async()
        future.add_done_callback(self._on_cancel_ack)

    def _on_cancel_ack(self, future):
        self._cancel_inflight = False
        try:
            if not future.result().goals_canceling and self._machine.state == 'CANCELING':
                self._dispatch(self._machine.fail('Nav2 목표 취소 승인 실패'))
        except Exception as exc:
            self._dispatch(self._machine.fail(f'Nav2 목표 취소 응답 실패: {exc}'))

    def _start_docking(self):
        if self._machine.state != 'DOCKING':
            return
        if (self.get_parameter('simulation_mode').value and
                self.get_parameter('simulate_docking').value):
            self._dispatch(self._machine.dock_simulated(self._now()))
            return
        if self._dock_client is None or not self._dock_client.server_is_ready():
            self._dispatch(self._machine.fail('Dock 액션 서버 없음'))
            return
        self._docking_inflight = True
        session = self._session
        self._emit({'request_id': self._machine.request_id, 'state': 'DOCK_REQUESTED',
                    'detail': 'irobot_create_msgs/action/Dock 요청',
                    'completed': list(self._machine.completed)})
        try:
            future = self._dock_client.send_goal_async(Dock.Goal())
            future.add_done_callback(lambda f: self._dock_accepted(f, session))
        except Exception as exc:
            self._docking_inflight = False
            self._dispatch(self._machine.fail(f'Dock 목표 전송 실패: {exc}'))

    def _dock_accepted(self, future, session):
        if session != self._session:
            return
        try:
            handle = future.result()
            if not handle.accepted:
                raise RuntimeError('Dock goal rejected')
            self._dock_goal = handle
            if self._machine.state != 'DOCKING':
                handle.cancel_goal_async()
                return
            handle.get_result_async().add_done_callback(
                lambda f: self._dock_finished(f, session))
        except Exception as exc:
            self._docking_inflight = False
            self._dispatch(self._machine.fail(f'Dock 요청 거절/오류: {exc}'))

    def _dock_finished(self, future, session):
        if session != self._session:
            return
        self._docking_inflight = False
        self._dock_goal = None
        if self._machine.state != 'DOCKING':
            return  # timeout already failed; never mark success on late response
        try:
            response = future.result()
            success = response.status == GoalStatus.STATUS_SUCCEEDED and bool(response.result.is_docked)
            self._dispatch(self._machine.docking_action_result(success, self._now()))
            if success and not self.get_parameter('require_dock_status').value:
                # Actual Dock action SUCCEEDED, but sensors aren't required by this setup.
                self._dispatch(self._machine.dock_confirmed(self._now()))
        except Exception as exc:
            self._dispatch(self._machine.fail(f'Dock 결과 조회 실패: {exc}'))

    def _on_explanation_result(self, msg):
        if self._machine is None or self.get_parameter('simulation_mode').value:
            return
        try:
            data = json.loads(msg.data)
            if data.get('request_id') != self._machine.request_id:
                return
            events = self._machine.explanation_result(
                str(data['artwork_id']), data['success'] is True, self._now())
            self._dispatch(events)
        except (ValueError, KeyError, TypeError) as exc:
            self.get_logger().warn(f'잘못된 해설 결과: {exc}')

    def _tick(self):
        if self._machine is None:
            return
        now = self._now()
        for client, future, active in list(self._lifecycle.values()):
            key = next(k for k,v in self._lifecycle.items() if v[0] is client)
            # REAL ROBOT: a get_state request can be lost over the discovery
            # server; re-ask after 2 s instead of waiting forever.
            if future is not None and not future.done() and now - self._lifecycle_sent.get(key, now) > 2.0:
                client.remove_pending_request(future)
                self._lifecycle[key][1] = future = None
            if future is not None and future.done():
                try: self._lifecycle[key][2] = future.result().current_state.id == 3
                except Exception: self._lifecycle[key][2] = False
                self._lifecycle[key][1] = None
            elif future is None and client.service_is_ready():
                self._lifecycle[key][1] = client.call_async(self._lifecycle_type.Request())
                self._lifecycle_sent[key] = now
        try:
            tf = self._tf_buffer.lookup_transform(self.get_parameter('map_frame').value, 'base_link', Time())
            if tf.header.stamp.sec or tf.header.stamp.nanosec:
                tf_time = tf.header.stamp.sec + tf.header.stamp.nanosec * 1e-9
                age = self.get_clock().now().nanoseconds * 1e-9 - tf_time
                if 0 <= age < 3.0:
                    self._tf_at = now
                    p = tf.transform.translation
                    q = tf.transform.rotation
                    yaw = math.atan2(2*(q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z))
                    self._pose = Pose2D(p.x, p.y, yaw)
                    self._pose_stamp = now
        except Exception:
            pass
        if self._await_sensors_since is not None:
            fresh = (self._pose is not None and now - self._pose_stamp < 3.0
                     and now - self._scan_stamp < 3.0
                     and (not self.get_parameter('require_tf').value or now - self._tf_at < 3.0))
            if not fresh:
                self._sensors_ok_since = None
            elif self._sensors_ok_since is None:
                self._sensors_ok_since = now
            elif now - self._sensors_ok_since >= float(self.get_parameter('post_undock_settle_time').value):
                self._sensors_ok_since = None
                self._finish_post_undock(now)
                return
            if now - self._await_sensors_since > float(self.get_parameter('post_undock_sensor_timeout').value):
                self._await_sensors_since = None
                self._pending_nav = None
                self._undock_failed_latched = True
                self._dispatch(self._machine.fail('언도킹 후 LiDAR/AMCL/TF 미수신 타임아웃'))
            return
        if self._undocking:
            if now - self._undock_started > float(self.get_parameter('undock_timeout').value):
                self._undocking = False
                self._undock_failed_latched = True
                if self._undock_goal is not None:
                    self._undock_goal.cancel_goal_async()
                self._dispatch(self._machine.fail('Undock 타임아웃; 로봇 상태 수동 점검·노드 재시작 필요'))
            return
        if self._machine.state in ('NAV_KIOSK', 'NAV_ARTWORK', 'NAV_HOME', 'NAV_EXIT', 'CANCELING',
                                   'CANCELING_HOME', 'CANCELING_EXIT',
                                   'VERIFY_STOP', 'VERIFY_HOME_STOP', 'VERIFY_EXIT_STOP',
                                   'FAREWELL', 'EXPLAINING',
                                   'DOCKING', 'WAIT_DOCK_CONFIRM'):
            pose_age = now - self._pose_stamp if self._pose else float('inf')
            odom_age = now - self._odom_stamp
            events = self._machine.tick(now, self._pose, pose_age, self._speed, odom_age)
            self._dispatch(events)
            if (self._machine.state == 'WAIT_DOCK_CONFIRM' and self._is_docked is True
                    and 0 <= now-self._dock_status_stamp < 3.0):
                self._dispatch(self._machine.dock_confirmed(now))
            if self._machine.state == 'ERROR':
                if self._goal_handle is not None or self._nav_inflight:
                    self._cancel_nav()
                if self._explain_goal is not None:
                    self._explain_goal.cancel_goal_async()
                if self._dock_goal is not None:
                    self._dock_goal.cancel_goal_async()

    def _start_explanation(self, artwork_id):
        if self.get_parameter('explanation_transport').value == 'topic':
            if self._explanation_pub.get_subscription_count() == 0:
                self._dispatch(self._machine.fail('TTS 구독 노드가 없음: arti/explanation_request'))
                return
            art_id = self._machine.plan.artworks[self._machine.index].artwork_id
            request = {'request_id': self._machine.request_id, 'artwork_id': art_id}
            self._explanation_pub.publish(String(data=json.dumps(request, ensure_ascii=False)))
            self.get_logger().info(f'TTS 해설 요청: 작품 {art_id}')
            return
        if self._explain_client is None or not self._explain_client.server_is_ready():
            self._dispatch(self._machine.fail('ExplainArtwork 액션 서버 미준비 (arti_interfaces 확인)'))
            return
        goal = ExplainArtwork.Goal()
        goal.artwork_id = artwork_id
        if hasattr(goal, 'request_id'):
            goal.request_id = self._machine.request_id
        token = self._session
        self._explain_client.send_goal_async(goal).add_done_callback(
            lambda f: self._explain_accepted(f, token, artwork_id))

    def _explain_accepted(self, future, token, artwork_id):
        if token != self._session or self._machine.state != 'EXPLAINING':
            return
        try:
            gh = future.result()
            if not gh.accepted:
                raise RuntimeError('ExplainArtwork goal rejected')
            self._explain_goal = gh
            gh.get_result_async().add_done_callback(
                lambda f: self._explain_finished(f, token, artwork_id))
        except Exception as exc:
            self._dispatch(self._machine.fail(f'해설 요청 실패: {exc}'))

    def _explain_finished(self, future, token, artwork_id):
        if token != self._session:
            return
        self._explain_goal = None
        try:
            response = future.result()
            ok = (response.status == GoalStatus.STATUS_SUCCEEDED
                  and bool(response.result.completed))
            self._dispatch(self._machine.explanation_result(artwork_id, ok, self._now()))
        except Exception as exc:
            self._dispatch(self._machine.fail(f'해설 결과 실패: {exc}'))

    def _on_recovery(self, msg):
        try:
            data = json.loads(msg.data)
            if (self._machine.state != 'WAIT_RECOVERY'
                or data.get('request_id') != self._machine.request_id
                or data.get('action') != 'retry'):
                return
            if self._nav_inflight or self._goal_handle is not None or self._cancel_inflight:
                self.get_logger().warn('Nav2 목표 취소 완료 전에는 복구 불가')
                return
            reason = self._check_ready()
            if reason:
                self.get_logger().warn(f'복구 거절: {reason}')
                return
            self._dispatch(self._machine.retry(self._now()))
        except (KeyError, ValueError, TypeError) as exc:
            self.get_logger().warn(f'잘못된 복구 요청: {exc}')


def main(args=None):
    rclpy.init(args=args)
    node = ACourseNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()


if __name__ == '__main__':
    main()
