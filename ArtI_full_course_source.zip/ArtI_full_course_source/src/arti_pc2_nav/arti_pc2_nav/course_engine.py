"""ROS-independent ArtI PC2 course state machine.

Full lifecycle: UNDOCK (ROS adapter) -> KIOSK -> ARTWORKS -> EXIT (farewell)
-> DOCK APPROACH -> DOCK action -> dock-status confirmation -> COMPLETED.
EXIT is used only when the plan has exit_goal; it is a point goal (no semicircle).
No object recognition / tracking; Nav2 owns all motion.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Optional
from .guided_tour_plan import CoursePlan, CourseRequest, Pose2D, resolve_selection


@dataclass(frozen=True)
class Event:
    kind: str  # status | navigate | cancel | guide | explain | dock
    value: object


class TourMachine:
    def __init__(self, plan: CoursePlan, *, stop_duration: float = 0.8,
                 stop_timeout: float = 20.0, navigation_timeout: float = 180.0,
                 explanation_timeout: float = 60.0, dock_timeout: float = 90.0,
                 confirmation_timeout: float = 12.0,
                 home_position_tolerance: float = 0.30,
                 simulate_explanation: bool = False, simulated_duration: float = 2.0,
                 max_retries: int = 2, exit_position_tolerance: float = 0.30,
                 farewell_duration: float = 2.0):
        self.base_plan = plan
        self.plan = plan
        self.stop_duration = stop_duration
        self.stop_timeout = stop_timeout
        self.navigation_timeout = navigation_timeout
        self.explanation_timeout = explanation_timeout
        self.dock_timeout = dock_timeout
        self.confirmation_timeout = confirmation_timeout
        self.home_position_tolerance = home_position_tolerance
        self.simulate_explanation = simulate_explanation
        self.simulated_duration = simulated_duration
        self.max_retries = max_retries
        self.exit_position_tolerance = exit_position_tolerance
        self.farewell_duration = farewell_duration
        self.state = 'IDLE'
        self.request_id = ''
        self.index = -1
        self.completed: list[str] = []
        self.dock_origin: Optional[Pose2D] = None  # robot pose before first undock
        self.home_goal: Optional[Pose2D] = None    # safe Nav2 return pose after undock
        self.last_pose: Optional[Pose2D] = None
        self.last_pose_at = float('-inf')
        self.still_since: Optional[float] = None
        self.state_since = 0.0
        self.retry_count = 0
        self.exit_pending = False

    def _event(self, state: str, detail: str = '') -> Event:
        return Event('status', {'request_id': self.request_id, 'state': state,
                                'detail': detail, 'completed': list(self.completed)})

    def start(self, request: CourseRequest, now: float, dock_origin: Pose2D) -> list[Event]:
        if self.state not in ('IDLE', 'DONE', 'ERROR'):
            raise ValueError('이미 코스주행 중입니다')
        if not isinstance(dock_origin, Pose2D) or not all(math.isfinite(x) for x in
                                  (dock_origin.x, dock_origin.y, dock_origin.yaw)):
            raise ValueError('언도킹 출발 위치(map 좌표)가 필요합니다')
        self.plan = resolve_selection(self.base_plan, request)
        self.request_id = request.request_id
        self.completed = []
        self.index = -1
        self.retry_count = 0
        self.dock_origin = dock_origin
        # Fixed dock approach from config wins; else skip_undock simulation fallback.
        self.home_goal = self.plan.dock_approach or dock_origin
        self.exit_pending = False
        self.state = 'NAV_KIOSK'
        self.state_since = now
        self.still_since = None
        self.last_pose = None
        self.last_pose_at = float('-inf')
        return [self._event('STARTED', ','.join(a.artwork_id for a in self.plan.artworks)),
                Event('navigate', ('kiosk', self.plan.kiosk_goal))]

    def set_post_undock_pose(self, pose: Pose2D):
        """Store physical, reachable pre-docking approach position after undocking.

        The precise original dock point is reached by Dock action, not by Nav2
        (Nav2 should not plan into a station/obstacle).
        """
        if not isinstance(pose, Pose2D) or not all(math.isfinite(x) for x in
                                                     (pose.x, pose.y, pose.yaw)):
            raise ValueError('언도킹 후 복귀 위치가 유효하지 않습니다')
        if self.state != 'NAV_KIOSK':
            raise ValueError('언도킹 완료 이전 상태에서만 접근 위치 저장 가능')
        self.home_goal = self.plan.dock_approach or pose

    def _zone(self):
        return self.plan.kiosk_zone if self.index < 0 else self.plan.artworks[self.index].zone

    def _fresh_pose(self, now: float) -> bool:
        return self.last_pose is not None and 0 <= now-self.last_pose_at < 2.0

    def _fresh_inside(self, now: float) -> bool:
        return self._fresh_pose(now) and self._zone().contains(self.last_pose)

    def _entry_inside(self, now: float) -> bool:
        """Require some depth inside the zone before canceling Nav2.

        Stopping exactly on the semicircle arc leaves no margin for AMCL
        jitter while the explanation runs, which can falsely trip the
        "left the artwork zone" check.
        """
        if not self._fresh_pose(now):
            return False
        zone, pose = self._zone(), self.last_pose
        return zone.contains(pose)

    def _fresh_exit(self, now: float) -> bool:
        goal = self.plan.exit_goal
        return (self._fresh_pose(now) and goal is not None and
                math.hypot(self.last_pose.x-goal.x, self.last_pose.y-goal.y)
                <= self.exit_position_tolerance)

    def _go_home(self, now: float, detail: str) -> list[Event]:
        self.state = 'NAV_HOME'
        self.state_since = now
        return [self._event('RETURNING_HOME', detail),
                Event('navigate', ('dock_approach', self.home_goal))]

    def _fresh_home(self, now: float) -> bool:
        return (self._fresh_pose(now) and self.home_goal is not None and
                math.hypot(self.last_pose.x-self.home_goal.x,
                           self.last_pose.y-self.home_goal.y) <= self.home_position_tolerance)

    def _recover(self, reason: str, now: float) -> list[Event]:
        if self.retry_count >= self.max_retries:
            return self.fail(f'복구 허용 횟수 초과: {reason}')
        self.state = 'WAIT_RECOVERY'
        self.state_since = now
        return [self._event('RECOVERY_REQUIRED', reason), Event('cancel', None)]

    def retry(self, now: float) -> list[Event]:
        """Operator-approved retry after Nav2 cancellation / full stop."""
        if self.state != 'WAIT_RECOVERY':
            raise ValueError('복구 승인 대기 상태가 아닙니다')
        self.retry_count += 1
        if self.exit_pending:
            self.state = 'NAV_EXIT'
        else:
            self.state = 'NAV_KIOSK' if self.index < 0 else ('NAV_HOME' if self.index == len(self.plan.artworks) else 'NAV_ARTWORK')
        self.state_since = now
        self.still_since = None
        if self.state == 'NAV_EXIT':
            target = ('exit', self.plan.exit_goal)
        elif self.state == 'NAV_KIOSK':
            target = ('kiosk', self.plan.kiosk_goal)
        elif self.state == 'NAV_HOME':
            target = ('return_to_undock', self.home_goal)
        else:
            art = self.plan.artworks[self.index]
            target = (art.artwork_id, art.goal)
        return [self._event('RECOVERY_RETRY', f'재시도 {self.retry_count}/{self.max_retries}'),
                Event('navigate', target)]

    def tick(self, now: float, pose: Optional[Pose2D], pose_age: float,
             speed: Optional[float], odom_age: float) -> list[Event]:
        if pose is not None and 0 <= pose_age < 2.0:
            self.last_pose = pose
            self.last_pose_at = now-pose_age
        if self.state in ('NAV_KIOSK', 'NAV_ARTWORK', 'NAV_HOME', 'NAV_EXIT'):
            # REAL ROBOT: Nav2 fine-positioning near the dock/exit trips its
            # progress checker. Cancel once within tolerance, like the zones;
            # the Dock action performs the final approach.
            if self.state == 'NAV_HOME' and self._fresh_home(now):
                self.state = 'CANCELING_HOME'
                self.state_since = now
                return [self._event('HOME_ZONE_ENTERED', 'Nav2 목표 취소 요청'), Event('cancel', None)]
            if self.state == 'NAV_EXIT' and self._fresh_exit(now):
                self.state = 'CANCELING_EXIT'
                self.state_since = now
                return [self._event('EXIT_ZONE_ENTERED', 'Nav2 목표 취소 요청'), Event('cancel', None)]
            if self.state not in ('NAV_HOME', 'NAV_EXIT') and self._entry_inside(now):
                self.state = 'CANCELING'
                self.state_since = now
                return [self._event('ZONE_ENTERED', 'Nav2 목표 취소 요청'), Event('cancel', None)]
            if now-self.state_since >= self.navigation_timeout:
                return self._recover('Nav2 이동 시간 초과', now)
        elif self.state in ('CANCELING', 'CANCELING_HOME', 'CANCELING_EXIT'):
            if now-self.state_since > 12.0:
                return self.fail('Nav2 목표 취소 결과 시간 초과')
        elif self.state == 'FAREWELL':
            if now-self.state_since >= self.farewell_duration:
                self.exit_pending = False
                return self._go_home(now, '출구 인사 완료; 충전 스테이션 접근 위치로 이동')
        elif self.state in ('VERIFY_STOP', 'VERIFY_HOME_STOP', 'VERIFY_EXIT_STOP'):
            if now-self.state_since > self.stop_timeout:
                return self.fail('목표 지역 내 정지 확인 시간 초과')
            if self.state == 'VERIFY_HOME_STOP':
                safe_location = self._fresh_home(now)
            elif self.state == 'VERIFY_EXIT_STOP':
                safe_location = self._fresh_exit(now)
            else:
                safe_location = self._fresh_inside(now)
            safe = (safe_location and speed is not None and 0 <= odom_age < 2.0 and speed < 0.035)
            if not safe:
                self.still_since = None
                return []
            if self.still_since is None:
                self.still_since = now
                return []
            if now-self.still_since < self.stop_duration:
                return []
            self.retry_count = 0
            if self.state == 'VERIFY_EXIT_STOP':
                self.state = 'FAREWELL'
                self.state_since = now
                return [self._event('EXIT_ARRIVED', self.plan.farewell_text),
                        Event('guide', self.plan.farewell_text)]
            if self.state == 'VERIFY_HOME_STOP':
                self.state = 'DOCKING'
                self.state_since = now
                return [self._event('HOME_ARRIVED', '충전 스테이션 접근 위치 도착; Dock 액션 실행'),
                        Event('dock', None)]
            if self.index < 0:
                self.index = 0
                self.state = 'NAV_ARTWORK'
                self.state_since = now
                first = self.plan.artworks[0]
                return [self._event('KIOSK_STOPPED', '객체인식 단계는 PC2 단독 시뮬레이션에서 제외'),
                        Event('guide', 'start'), Event('navigate', (first.artwork_id, first.goal))]
            self.state = 'EXPLAINING'
            self.state_since = now
            art = self.plan.artworks[self.index]
            return [self._event('ARTWORK_STOPPED', art.artwork_id), Event('explain', art.explanation_id)]
        elif self.state == 'EXPLAINING':
            if not self._fresh_inside(now):
                return self.fail('해설 중 현재 작품 반원 이탈 또는 위치 정보 소실')
            if self.simulate_explanation and now-self.state_since >= self.simulated_duration:
                return self.explanation_result(self.plan.artworks[self.index].artwork_id, True, now)
            if now-self.state_since >= self.explanation_timeout:
                return self.fail('해설 완료 응답 시간 초과')
        elif self.state == 'DOCKING':
            if now-self.state_since >= self.dock_timeout:
                return self.fail('Dock 액션 시간 초과')
        elif self.state == 'WAIT_DOCK_CONFIRM':
            if now-self.state_since >= self.confirmation_timeout:
                return self.fail('Dock 액션 성공 이후 dock_status.is_docked 확인 실패')
        return []

    def nav_result(self, result: str, now: float) -> list[Event]:
        if self.state not in ('NAV_KIOSK', 'NAV_ARTWORK', 'NAV_HOME', 'NAV_EXIT', 'CANCELING',
                              'CANCELING_HOME', 'CANCELING_EXIT'):
            return []
        if self.state == 'CANCELING_HOME':
            if result in ('CANCELED', 'SUCCEEDED') and self._fresh_home(now):
                return self._begin_stop(now, home=True)
            return self._recover(f'복귀 Nav2 {result}; 접근 위치 이탈', now)
        if self.state == 'CANCELING_EXIT':
            self.state = 'NAV_EXIT'  # reuse NAV_EXIT success path below
            result = 'SUCCEEDED' if result in ('CANCELED', 'SUCCEEDED') else result
        if self.state == 'NAV_EXIT':
            if result == 'SUCCEEDED' and self._fresh_exit(now):
                self.state = 'VERIFY_EXIT_STOP'
                self.state_since = now
                self.still_since = None
                return [self._event('VERIFY_EXIT_STOP', '출구 목표점 도착 및 정지 확인')]
            return self._recover(f'출구 이동 Nav2 {result}; 출구 도착 미확인', now)
        if self.state == 'NAV_HOME':
            if result == 'SUCCEEDED' and self._fresh_home(now):
                return self._begin_stop(now, home=True)
            if result in ('ABORTED', 'REJECTED'):
                return self._recover(f'복귀 경로 Nav2 {result}', now)
            return self.fail(f'Nav2 {result}: 초기 언도킹 접근 위치 복귀 미확인')
        if result == 'SUCCEEDED' and self._fresh_inside(now):
            return self._begin_stop(now)
        if result == 'CANCELED' and self.state == 'CANCELING' and self._fresh_inside(now):
            return self._begin_stop(now)
        if result in ('ABORTED', 'REJECTED'):
            return self._recover(f'Nav2 {result}; 운영자 복구 승인 필요', now)
        return self._recover(f'Nav2 {result}: 현재 반원 도착 미확인; 동일 목표 재검증 필요', now)

    def _begin_stop(self, now: float, *, home: bool = False) -> list[Event]:
        self.state = 'VERIFY_HOME_STOP' if home else 'VERIFY_STOP'
        self.state_since = now
        self.still_since = None
        return [self._event(self.state, '목표 위치 내부 및 Odometry 연속 정지 확인')]

    def explanation_result(self, artwork_id: str, success: bool, now: float) -> list[Event]:
        if self.state != 'EXPLAINING':
            return []
        active = self.plan.artworks[self.index].artwork_id
        if artwork_id != active:
            return self.fail(f'잘못된 작품 해설 응답: {artwork_id} != {active}')
        if not self._fresh_inside(now):
            return self.fail('해설 완료 시점에 현재 작품 반원 밖 또는 위치 정보 만료')
        if not success:
            return self.fail(f'작품 {active} 해설 실패')
        self.completed.append(active)
        events = [self._event('ARTWORK_COMPLETED', active)]
        self.index += 1
        self.retry_count = 0
        if self.index == len(self.plan.artworks):
            if self.plan.exit_goal is not None:
                self.exit_pending = True
                self.state = 'NAV_EXIT'
                self.state_since = now
                events.extend([self._event('NAV_TO_EXIT', '모든 작품 방문 완료; 출구로 이동'),
                               Event('navigate', ('exit', self.plan.exit_goal))])
            else:
                events.extend(self._go_home(now, '모든 작품 방문 완료; 언도킹 접근 위치 복귀'))
        else:
            self.state = 'NAV_ARTWORK'
            self.state_since = now
            nxt = self.plan.artworks[self.index]
            events.append(Event('navigate', (nxt.artwork_id, nxt.goal)))
        return events

    def docking_action_result(self, success: bool, now: float) -> list[Event]:
        if self.state != 'DOCKING':
            return []
        if not success:
            return self.fail('Dock 액션 실패/거절/취소')
        self.state = 'WAIT_DOCK_CONFIRM'
        self.state_since = now
        return [self._event('DOCK_ACTION_SUCCEEDED', 'dock_status.is_docked 확인 대기')]

    def dock_confirmed(self, now: float) -> list[Event]:
        if self.state != 'WAIT_DOCK_CONFIRM':
            return []
        self.state = 'DONE'
        self.state_since = now
        return [self._event('DOCKED', '도킹 액션 및 is_docked 상태 확인'),
                Event('guide', 'tour_end'),
                self._event('COMPLETED', '전체 작품 관람 + 원위치 복귀 + 실제 도킹 완료; PC3 예약 해제 요청')]

    def dock_simulated(self, now: float) -> list[Event]:
        """Explicit opt-in mock for ROS integration; NOT a physical docking success."""
        if self.state != 'DOCKING':
            return []
        self.state = 'DONE'
        self.state_since = now
        return [self._event('SIMULATED_DOCKING', '실제 Dock 액션 없이 시뮬레이션 완료'),
                self._event('SIMULATED_COMPLETED', '물리 도킹 검증 전; 실제 COMPLETED와 구분')]

    def fail(self, reason: str) -> list[Event]:
        if self.state in ('IDLE', 'DONE', 'ERROR'):
            return []
        self.state = 'ERROR'
        return [self._event('FAILED', reason)]
