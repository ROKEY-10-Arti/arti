"""DB 연결 전 사용할 짧은 임시 작품 해설. 나중에 DB 조회로 교체할 수 있습니다."""

EXPLANATIONS = {
    '1': '1번 작품을 감상하세요.',
    '2': '2번 작품을 감상하세요.',
    '3': '3번 작품을 감상하세요.',
    '4': '4번 작품을 감상하세요.',
}


def explanation_for(artwork_id: str) -> str:
    try:
        return EXPLANATIONS[str(artwork_id)]
    except KeyError as exc:
        raise ValueError(f'해설이 등록되지 않은 작품 ID: {artwork_id}') from exc
