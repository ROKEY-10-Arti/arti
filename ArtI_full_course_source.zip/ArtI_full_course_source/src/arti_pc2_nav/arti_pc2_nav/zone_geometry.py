"""RViz semicircle geometry; exit endpoints updated 2026-11-17.

The pair defines the *diameter*, not the semicircle center/radius. The gallery
interior (-X side) is selected explicitly rather than inferring a fixed side
from the order of the two supplied endpoints.
"""
import math
from .guided_tour_plan import Semicircle

EXIT_DIAMETER_A = (0.167, 1.95)
EXIT_DIAMETER_B = (0.147, 2.28)


def exit_semicircle() -> Semicircle:
    ax, ay = EXIT_DIAMETER_A
    bx, by = EXIT_DIAMETER_B
    cx, cy = (ax + bx) / 2.0, (ay + by) / 2.0
    dx, dy = bx - ax, by - ay
    radius = math.hypot(dx, dy) / 2.0
    # Left-side normal of diameter A -> B = (-dy, dx), predominantly -X.
    # This preserves the original gallery-interior (-X) half-plane.
    direction = math.atan2(dx, -dy)
    return Semicircle(cx, cy, radius, direction)


def boundary_points(zone: Semicircle, steps: int = 40):
    """Curved arc; to close the region connect first and last points."""
    if steps < 2:
        raise ValueError('steps must be >= 2')
    return [
        (zone.cx + zone.radius * math.cos(zone.direction - math.pi/2 + math.pi*i/steps),
         zone.cy + zone.radius * math.sin(zone.direction - math.pi/2 + math.pi*i/steps))
        for i in range(steps + 1)
    ]
