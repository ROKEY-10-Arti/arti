"""Starts ArtI PC2 course controller and RViz zone markers; not Gazebo itself.

Launch alongside your project's original simulator after disabling its legacy
arti_gallery/a_course_node. Driving is locked off by default.
"""
from pathlib import Path
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    pkg = Path(get_package_share_directory('arti_pc2_nav'))
    return LaunchDescription([
        DeclareLaunchArgument('robot_namespace', default_value='robot4'),
        DeclareLaunchArgument('config_file', default_value=str(pkg / 'config/a_course.yaml')),
        DeclareLaunchArgument('enable_motion', default_value='false'),
        DeclareLaunchArgument('simulation_mode', default_value='false'),
        DeclareLaunchArgument('use_sim_time', default_value='false'),
        DeclareLaunchArgument('skip_undock', default_value='false'),
        DeclareLaunchArgument('simulate_docking', default_value='false'),
        DeclareLaunchArgument('require_dock_status', default_value='true'),
        DeclareLaunchArgument('simulation_battery_percent', default_value='-1.0'),
        DeclareLaunchArgument('explanation_transport', default_value='topic'),
        DeclareLaunchArgument('start_tts', default_value='true'),
        DeclareLaunchArgument('tts_engine', default_value='gtts'),
        Node(package='arti_pc2_nav', executable='a_course_node', name='a_course_node',
             namespace=LaunchConfiguration('robot_namespace'), output='screen',
             remappings=[('/tf','tf'),('/tf_static','tf_static')],
             parameters=[{
                 'config_file': LaunchConfiguration('config_file'),
                 'enable_motion': ParameterValue(LaunchConfiguration('enable_motion'), value_type=bool),
                 'simulation_mode': ParameterValue(LaunchConfiguration('simulation_mode'), value_type=bool),
                 'use_sim_time': ParameterValue(LaunchConfiguration('use_sim_time'), value_type=bool),
                 'skip_undock': ParameterValue(LaunchConfiguration('skip_undock'), value_type=bool),
                 'simulate_docking': ParameterValue(LaunchConfiguration('simulate_docking'), value_type=bool),
                 'require_dock_status': ParameterValue(LaunchConfiguration('require_dock_status'), value_type=bool),
                 'simulation_battery_percent': ParameterValue(LaunchConfiguration('simulation_battery_percent'), value_type=float),
                 'explanation_transport': LaunchConfiguration('explanation_transport'),
             }]),
        Node(package='arti_pc2_nav', executable='hardcoded_tts_node', name='hardcoded_tts_node',
             namespace=LaunchConfiguration('robot_namespace'), output='screen',
             condition=IfCondition(LaunchConfiguration('start_tts')),
             parameters=[{'engine': LaunchConfiguration('tts_engine')}]),
        Node(package='arti_pc2_nav', executable='zone_marker_node', name='arti_zone_markers',
             namespace=LaunchConfiguration('robot_namespace'), output='screen',
             parameters=[{
                 'config_file': LaunchConfiguration('config_file'),
                 'use_sim_time': ParameterValue(LaunchConfiguration('use_sim_time'), value_type=bool),
                 'map_frame': 'map',
             }]),
    ])
