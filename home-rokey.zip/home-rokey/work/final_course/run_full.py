import rclpy,time,json
from std_msgs.msg import String
from lifecycle_msgs.srv import GetState
rclpy.init();n=rclpy.create_node('course_trial');p=n.create_publisher(String,'/robot4/arti/tour/select',10);c=n.create_client(GetState,'/robot4/bt_navigator/get_state');f=None;sent=False;done=False;last=0

def status(m):
 global done
 print(m.data,flush=True)
 d=json.loads(m.data)
 if d.get('state') in ('COMPLETED','FAILED'):done=True
 if d.get('state')=='REJECTED':
  global sent,last
  sent=False;last=time.monotonic()+5
n.create_subscription(String,'/arti/course_status',status,10)
end=time.monotonic()+1800
while time.monotonic()<end and not done:
 rclpy.spin_once(n,timeout_sec=.2)
 if not sent and time.monotonic()>last and c.service_is_ready():
  if f is None:f=c.call_async(GetState.Request())
  elif f.done():
   if f.result().current_state.label=='active' and p.get_subscription_count():p.publish(String(data='A'));sent=True;print('SENT A',flush=True)
   f=None
n.destroy_node();rclpy.shutdown()
