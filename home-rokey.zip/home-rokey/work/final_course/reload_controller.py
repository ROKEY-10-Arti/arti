import rclpy,time
from action_msgs.srv import CancelGoal
from lifecycle_msgs.srv import ChangeState
rclpy.init();n=rclpy.create_node('arti_controller_reconfigure')
def call(typ,name,req):
 c=n.create_client(typ,name)
 if not c.wait_for_service(timeout_sec=5):raise RuntimeError(name)
 f=c.call_async(req);rclpy.spin_until_future_complete(n,f,timeout_sec=8)
 print(name, f.result(),flush=True)
call(CancelGoal,'/robot4/navigate_to_pose/_action/cancel_goal',CancelGoal.Request())
end=time.monotonic()+2
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
for t in (4,2,1,3):
 q=ChangeState.Request();q.transition.id=t;call(ChangeState,'/robot4/controller_server/change_state',q)
n.destroy_node();rclpy.shutdown()
