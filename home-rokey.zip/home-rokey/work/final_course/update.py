from pathlib import Path
import shutil,datetime
r=Path('/home/rokey/f_project'); b=r/'backups'/('final_full_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));b.mkdir(parents=True)
p=r/'src/arti_pc2_nav/arti_pc2_nav/a_course_node.py';shutil.copy2(p,b/p.name);s=p.read_text()
s=s.replace("self.declare_parameter('skip_undock', True)","self.declare_parameter('skip_undock', False)")
s=s.replace("self.declare_parameter('require_tf', True)","""self.declare_parameter('require_tf', True)
        from lifecycle_msgs.srv import GetState
        self._lifecycle_type = GetState
        self._lifecycle = {name: [self.create_client(GetState, name+'/get_state'), None, False]
                           for name in ('amcl','map_server','bt_navigator','controller_server','planner_server')}""")
s=s.replace('return time.monotonic()', 'return self.get_clock().now().nanoseconds * 1e-9')
s=s.replace("        # Fail before navigation", "        if not all(v[2] for v in self._lifecycle.values()):\n            return 'AMCL/map_server/Nav2 lifecycle not active'\n        # Fail before navigation")
s=s.replace("        self._session += 1", "        if not req.all_artworks:\n            self._reject('이번 구현은 전체 코스 A 전용입니다'); return\n        if self._is_docked is None or self._now()-self._dock_status_stamp > 3.0:\n            self._reject('최신 dock_status 없음'); return\n        self._session += 1",1)
s=s.replace("        if self.get_parameter('skip_undock').value:", "        if self._is_docked is False:\n            self._machine.set_post_undock_pose(self._pose)\n            self._dispatch(events)\n        elif self.get_parameter('skip_undock').value:",1)
s=s.replace("            self._machine.set_post_undock_pose(self._pose)", "            self._machine.set_post_undock_pose(self._pose)",1)
# Face the original dock when returning to the safe post-undock position.
s=s.replace("            self._machine.set_post_undock_pose(self._pose)\n            self._emit", "            origin = self._machine.dock_origin\n            home = Pose2D(self._pose.x, self._pose.y, math.atan2(origin.y-self._pose.y, origin.x-self._pose.x))\n            self._machine.set_post_undock_pose(home)\n            self._emit")
s=s.replace("        now = self._now()\n        try:\n            tf =", """        now = self._now()
        for client, future, active in list(self._lifecycle.values()):
            key = next(k for k,v in self._lifecycle.items() if v[0] is client)
            if future is not None and future.done():
                try: self._lifecycle[key][2] = future.result().current_state.id == 3
                except Exception: self._lifecycle[key][2] = False
                self._lifecycle[key][1] = None
            elif future is None and client.service_is_ready():
                self._lifecycle[key][1] = client.call_async(self._lifecycle_type.Request())
        try:
            tf =""")
s=s.replace("        rclpy.shutdown()", "        if rclpy.ok(): rclpy.shutdown()")
p.write_text(s)
p=r/'simulation/arti_sim.launch.py';shutil.copy2(p,b/p.name);s=p.read_text().replace("'skip_undock',default_value='true'","'skip_undock',default_value='false'").replace("'simulate_docking',default_value='true'","'simulate_docking',default_value='false'");p.write_text(s)
p=r/'src/arti_pc2_nav/launch/a_course.launch.py';s=p.read_text().replace("'use_sim_time', default_value='true'","'use_sim_time', default_value='false'")
s=s.replace("parameters=[{\n                 'config_file'", "remappings=[('/tf','tf'),('/tf_static','tf_static')],\n             parameters=[{\n                 'config_file'",1);p.write_text(s)
p=r/'src/arti_pc2_nav/package.xml';s=p.read_text().replace('<export>','<exec_depend>lifecycle_msgs</exec_depend>\n  <export>');p.write_text(s)
# 5ms physics avoids wasting CPU on 1000Hz physics in this desktop simulation.
p=r/'simulation/arti_gallery.sdf';s=p.read_text().replace('<max_step_size>0.001</max_step_size>','<max_step_size>0.005</max_step_size>');p.write_text(s)
print('Backup:',b)
