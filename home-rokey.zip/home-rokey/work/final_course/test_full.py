import unittest
from arti_pc2_nav.course_engine import TourMachine
from arti_pc2_nav.guided_tour_plan import load_course_config,parse_course_request,Pose2D
from arti_pc2_nav.zone_geometry import exit_semicircle
P='/home/rokey/f_project/src/arti_pc2_nav/config/a_course.yaml'
class Tests(unittest.TestCase):
 def setUp(self):self.m=TourMachine(load_course_config(P));self.m.start(parse_course_request('A'),0,Pose2D(0,0))
 def test_half_plane(self):
  z=self.m.plan.artworks[0].zone
  self.assertFalse(z.contains((z.cx-.1,z.cy)));self.assertTrue(z.contains((z.cx+.1,z.cy)))
 def test_exit(self):
  z=exit_semicircle();self.assertAlmostEqual(z.cx,.157);self.assertAlmostEqual(z.cy,2.115);self.assertTrue(z.contains((.1,2.115)))
 def test_dock_needs_confirmation(self):
  self.m.state='DOCKING';events=self.m.docking_action_result(True,1);self.assertEqual(self.m.state,'WAIT_DOCK_CONFIRM');self.assertNotIn('COMPLETED',str(events));self.assertIn('COMPLETED',str(self.m.dock_confirmed(2)))
 def test_dock_fail(self):
  self.m.state='DOCKING';self.m.docking_action_result(False,1);self.assertEqual(self.m.state,'ERROR')
 def test_no_complete_after_art4(self):
  m=self.m;m.index=3;m.state='EXPLAINING';m.last_pose=m.plan.artworks[3].goal;m.last_pose_at=5
  m.explanation_result('4',True,5);self.assertEqual(m.state,'NAV_HOME')
 def test_stop_requires_odom(self):
  m=self.m;m.state='VERIFY_STOP';p=m.plan.kiosk_goal
  m.tick(1,p,0,None,99);m.tick(2,p,0,None,99);self.assertEqual(m.state,'VERIFY_STOP')
 def test_full_mission_requires_every_artwork_and_physical_dock(self):
  m=self.m;t=1.;zones=[m.plan.kiosk_goal]+[a.goal for a in m.plan.artworks]
  for index,pose in enumerate(zones):
   m.tick(t,pose,0,0,0)
   self.assertEqual(m.state,'CANCELING')
   m.nav_result('CANCELED',t)
   m.tick(t+.1,pose,0,0,0);m.tick(t+1,pose,0,0,0)
   if index:
    self.assertEqual(m.state,'EXPLAINING');m.explanation_result(str(index),True,t+1)
   t+=2
  self.assertEqual(m.completed,['1','2','3','4']);self.assertEqual(m.state,'NAV_HOME')
  m.tick(t,m.home_goal,0,0,0);m.nav_result('SUCCEEDED',t)
  m.tick(t+.1,m.home_goal,0,0,0);m.tick(t+1,m.home_goal,0,0,0)
  self.assertEqual(m.state,'DOCKING');m.docking_action_result(True,t+2)
  self.assertEqual(m.state,'WAIT_DOCK_CONFIRM');m.dock_confirmed(t+3)
  self.assertEqual(m.state,'DONE')
if __name__=='__main__':unittest.main()
