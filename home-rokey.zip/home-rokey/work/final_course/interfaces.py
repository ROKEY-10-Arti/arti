import rclpy,time,json
from rclpy.action import get_action_client_names_and_types_by_node
rclpy.init();n=rclpy.create_node('arti_interface_audit');end=time.monotonic()+8
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
for name,fn in [('subscriptions',n.get_subscriber_names_and_types_by_node),('publications',n.get_publisher_names_and_types_by_node),('services',n.get_client_names_and_types_by_node)]:
 print(name,json.dumps(fn('a_course_node','/robot4'),ensure_ascii=False))
print('actions',json.dumps(get_action_client_names_and_types_by_node(n,'a_course_node','/robot4')))
n.destroy_node();rclpy.shutdown()
