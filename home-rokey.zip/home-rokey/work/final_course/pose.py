import rclpy,time
from tf2_ros import Buffer,TransformListener
rclpy.init();n=rclpy.create_node('pose_audit');b=Buffer();l=TransformListener(b,n);end=time.monotonic()+6
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
try:
 t=b.lookup_transform('map','base_link',rclpy.time.Time());print(t)
except Exception as e:print(e)
n.destroy_node();rclpy.shutdown()
