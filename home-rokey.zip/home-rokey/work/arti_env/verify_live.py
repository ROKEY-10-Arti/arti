import rclpy,time,json
from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseWithCovarianceStamped
from visualization_msgs.msg import MarkerArray
from lifecycle_msgs.srv import GetState
rclpy.init();n=rclpy.create_node('arti_sim_verification');seen={}
q=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)
def record(k,v):
 if k not in seen:seen[k]=v;print(k,json.dumps(v),flush=True)
n.create_subscription(OccupancyGrid,'/robot4/map',lambda m:record('map',{'w':m.info.width,'h':m.info.height,'res':m.info.resolution,'origin':[m.info.origin.position.x,m.info.origin.position.y]}),q)
n.create_subscription(PoseWithCovarianceStamped,'/robot4/amcl_pose',lambda m:record('amcl',{'x':m.pose.pose.position.x,'y':m.pose.pose.position.y}),q)
n.create_subscription(LaserScan,'/robot4/scan',lambda m:record('scan',len(m.ranges)),QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT))
n.create_subscription(MarkerArray,'/robot4/arti/a_course/zones',lambda m:record('zones',len(m.markers)),10)
c=n.create_client(GetState,'/robot4/bt_navigator/get_state');future=None;end=time.monotonic()+55
while time.monotonic()<end:
 rclpy.spin_once(n,timeout_sec=.1)
 if future is None and c.service_is_ready():future=c.call_async(GetState.Request())
 if future and future.done():
  record('nav2',future.result().current_state.label);future=None
  if seen.get('nav2')!='active':seen.pop('nav2',None)
 if len(seen)==5:break
print('RESULT',json.dumps(seen),flush=True)
n.destroy_node();rclpy.shutdown()
