"""Final diagram course branch; real Nav2 motion, explicitly simulated narration.
No perception subscription is enabled. Production audio/service types must be supplied.
"""
import json, math, time, uuid
from pathlib import Path
import rclpy
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import BatteryState
from std_msgs.msg import String
from tf2_ros import Buffer, TransformListener
from arti_gallery.a_course_node import ACourseNode
from arti_gallery.guided_tour_plan import resolve_selection, parse_course_request

class CourseSimulation(ACourseNode):
 def __init__(self):
  super().__init__()
  if not self.get_parameter('use_sim_time').value or self._dry_run:
   raise RuntimeError('Simulation clock and dry_run=false required')
  self.request_id=str(uuid.uuid4()); self.completed=[]; self.pending=None; self.still=None
  self.odom_at=0.; self.speed=99.; self.battery=None; self.scan_at=0.;self.amcl_seen=False
  self.base_course=self._course
  self.report=self.create_publisher(String,'/arti/course_status',10)
  self.guide=self.create_publisher(String,'guide_message',10)
  self.create_subscription(Odometry,'odom',self.on_odom,qos_profile_sensor_data)
  self.create_subscription(BatteryState,'battery_state',lambda m:setattr(self,'battery',m.percentage),qos_profile_sensor_data)
  from sensor_msgs.msg import LaserScan
  self.create_subscription(LaserScan,'scan',lambda m:setattr(self,'scan_at',time.monotonic()),qos_profile_sensor_data)
  self.create_subscription(String,'arti/tour/select',self.select,10)
  self.buf=Buffer(); self.listener=TransformListener(self.buf,self)
  self.tick=self.create_timer(.1,self.check)
  self.emit('READY','simulation narration only; perception disabled')
  # TODO(PERCEPTION TEAM): after kiosk arrival connect registration result + stable
  # person ID / validity / timestamp / map PointStamped, agreed with tracker team.
  # self.create_subscription(PointStamped, 'target_person/point_map', self.on_person, 10)
  # TODO: on stale/lost target cancel Nav2 and wait for the same registered person.
  # This simulation deliberately bypasses registration; it never fabricates detections.
  # TODO(AUDIO TEAM): replace the explicit 2s simulated narration below with
  # arti_interfaces/action/ExplainArtwork result.completed, cancel on zone exit.
  # TODO(CENTRAL TEAM): adapt /arti/get_course response to resolve_selection;
  # exact service definition not included in f_project. Current input: A or B:1,3.
 def emit(self,state,detail=''):
  d={'request_id':self.request_id,'state':state,'detail':detail,'completed':self.completed,'simulation':True}
  self.report.publish(String(data=json.dumps(d,ensure_ascii=False)))
  self.get_logger().info(json.dumps(d,ensure_ascii=False))
 def on_odom(self,m):
  self.odom_at=time.monotonic();self.speed=max(math.hypot(m.twist.twist.linear.x,m.twist.twist.linear.y),abs(m.twist.twist.angular.z))
 def _on_amcl_pose(self,m):
  self.amcl_seen=True
  super()._on_amcl_pose(m)
 def select(self,m):
  if self._state not in ('IDLE','DONE','ERROR'):return
  try:
   code,sel=parse_course_request(m.data);self._course=resolve_selection(self.base_course,{},code,sel)
  except Exception as e:self.emit('REJECTED',str(e));return
  if not self.amcl_seen or time.monotonic()-self.scan_at>3 or not self._has_fresh_pose() or not self._nav_client.server_is_ready():
   self.emit('REJECTED','localization/scan/Nav2 not ready');return
  if self.battery is None or not math.isfinite(self.battery) or self.battery<.3:
   self.emit('REJECTED','battery unavailable or below 30%');return
  self.request_id=str(uuid.uuid4());self.completed=[];self._start()
 def _after_undock(self):
  self.emit('UNDOCKED');self._begin_nav()
 def _on_kiosk_arrived(self):self.wait_stop('kiosk')
 def _arrived(self):self.wait_stop('artwork')
 def wait_stop(self,kind):
  self.pending=kind;self.still=None;self.deadline=time.monotonic()+30;self._state='VERIFY_STOP'
 def check(self):
  now=time.monotonic()
  try:
   t=self.buf.lookup_transform('map','base_link',rclpy.time.Time())
   age=(self.get_clock().now().nanoseconds-(t.header.stamp.sec*10**9+t.header.stamp.nanosec))/1e9
   if 0<=age<2:
    m=PoseWithCovarianceStamped();m.header.frame_id='map';m.pose.pose.position.x=t.transform.translation.x;m.pose.pose.position.y=t.transform.translation.y;m.pose.pose.orientation=t.transform.rotation
    super()._on_amcl_pose(m)
  except Exception:pass
  if self._state not in ('VERIFY_STOP','SIM_NARRATION'):return
  zone=self._course.kiosk_zone if self.pending=='kiosk' else self._course.stops[self._index].zone
  safe=self._has_fresh_pose() and zone.contains(self._current_pose) and now-self.odom_at<2 and self.speed<.03
  if not safe:
   self.still=None
   if self._state=='SIM_NARRATION' or now>self.deadline:self._fail('stop/zone verification failed')
   return
  if self._state=='VERIFY_STOP':
   if self.still is None:self.still=now
   if now-self.still<.7:return
   if self.pending=='kiosk':
    self.guide.publish(String(data='start'));self.emit('KIOSK_STOPPED','perception bypassed for simulation');self._navigate_current();return
   self._state='SIM_NARRATION';self.deadline=now+2;self.emit('SIM_NARRATION',self._course.stops[self._index].artwork_id)
  elif now>=self.deadline:
   self.completed.append(self._course.stops[self._index].artwork_id);self.emit('ARTWORK_COMPLETED');self._next()
 def _next(self):
  self._index+=1
  if self._index>=len(self._course.stops):
   self._state='DONE';self.guide.publish(String(data='tour_end'));self.emit('COMPLETED','reservation release requested; no exit/dock in final course branch')
  else:self._navigate_current()
 def _recover_from_zone_miss(self,name,zone):self._fail(name+' outside zone; operator recovery required')
 def _fail(self,reason):
  if self._goal_handle:self._goal_handle.cancel_goal_async()
  super()._fail(reason)
  if hasattr(self,'report'):self.emit('FAILED',reason)

def main():
 rclpy.init();n=CourseSimulation()
 try:rclpy.spin(n)
 except KeyboardInterrupt:n._cancel()
 finally:n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
