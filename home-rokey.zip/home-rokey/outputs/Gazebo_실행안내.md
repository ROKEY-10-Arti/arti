# ArtI 전시장 시뮬레이션

```bash
cd /home/rokey/f_project
./sim-start
```

Gazebo는 `simulation/arti_gallery.sdf`, RViz/AMCL은 원본 `maps/gallery.yaml`을 사용합니다. 기존 창고/SLAM 실행을 ArtI 저장 지도/AMCL 실행으로 교체했습니다.

- 원본 지도: 66×121픽셀, 0.05m/픽셀, 원점 [-2.921, -0.6, 0].
- 원본 장애물 898개 셀을 정확히 덮는 103개 직육면체로 외곽 벽과 중앙 구조물을 생성했습니다. 벽 높이 1.2m는 2D 지도에 높이가 없어 시뮬레이션용으로 설정한 값입니다. 미탐색 셀은 임의의 벽으로 만들지 않았습니다.
- `turtlebot_project/src/person_tracker/maps/gallery.*`는 다른 버전(72×126, 원점 [-3.048, -1.312, 0])입니다. 최신 A코스와 함께 있는 최상위 `maps/gallery.*`를 사용합니다.
- 로봇 시작점은 (-0.2, 0, yaw=0)입니다. 원본 A코스의 시작점 (0.304,-0.0957)은 이 지도에서 장애물 셀에 들어가므로 원본 코스는 보존하고 시뮬레이터 생성 위치만 빈 공간으로 설정했습니다.
- RViz에 `src/arti_gallery/config/a_course.yaml`에서 읽은 키오스크·작품 1~4의 반원과 출구 마커 11개가 표시됩니다.
- 코스 노드는 `auto_start=false`로 대기합니다. 시뮬레이터 실행 자체로 코스가 자동 출발하지 않습니다.
- ROS_DOMAIN_ID=77, localhost UDP 전용. 다른 터미널은 `source /home/rokey/f_project/setup_sim.sh`를 먼저 실행합니다.

검증: 원본 지도 메타데이터 일치, AMCL (-0.2,0), 라이다 640개 샘플, 반원/출구 마커 11개, Nav2 active. 전체 코스 완주는 검증하지 않았습니다.

주요 파일:
- `simulation/arti_sim.launch.py`: Gazebo, 로봇, AMCL, Nav2, RViz, ArtI 코스 표시 통합
- `simulation/generate_environment.py`: 원본 지도에서 장애물 충돌벽 생성
- `simulation/localization.yaml`: 시뮬레이션 전용 초기 위치
- `simulation/arti.rviz`: ArtI 지도 중심 시점과 코스 표시
- `simulation/log/arti-current.log`: 실행 로그

지도 변경 후에는 `python3 /home/rokey/f_project/simulation/generate_environment.py`를 실행하고 시뮬레이터를 재시작합니다.
